# Note

- Create `.env` from .env.example and change necessary vars.
- Change Prometheus password inside `web.yml`